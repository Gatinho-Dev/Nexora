import devServer from "@hono/vite-dev-server"
import path from "path"
const __dirname = import.meta.dirname
import react from "@vitejs/plugin-react"
import { defineConfig, type Plugin } from "vite"
import { inspectAttr } from 'kimi-plugin-inspect-react'

// Attach the realtime WebSocket server to the Vite dev server (production
// attaches it in api/boot.ts).
function realtimeDevPlugin(): Plugin {
  return {
    name: "realtime-dev",
    configureServer(server) {
      if (!server.httpServer) return
      const httpServer = server.httpServer
      httpServer.once("listening", async () => {
        // Non-static specifier keeps server code out of this tsconfig's program
        const modulePath = "./api/realtime"
        const { attachRealtime } = await import(modulePath)
        attachRealtime(httpServer as unknown as import("http").Server)
      })
    },
  }
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    devServer({ entry: "api/boot.ts", exclude: [/^\/(?!api\/).*$/] }),
    realtimeDevPlugin(),
    inspectAttr(), react()],
  server: {
    port: 3000,
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
      "@contracts": path.resolve(__dirname, "./contracts"),
      "@db": path.resolve(__dirname, "./db"),
      "db": path.resolve(__dirname, "./db"),
    },
  },
  envDir: path.resolve(__dirname),
  build: {
    outDir: path.resolve(__dirname, "dist/public"),
    emptyOutDir: true,
  },
});
