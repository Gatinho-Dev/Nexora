import { useNavigate, useParams } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Users } from "lucide-react";

export function InvitePage() {
  const params = useParams();
  const navigate = useNavigate();
  const code = params.code ?? "";
  const { user, isLoading: authLoading } = useAuth();

  const info = trpc.server.getInviteInfo.useQuery({ code }, { enabled: !!code && !!user, retry: false });

  const join = trpc.server.joinByCode.useMutation({
    onSuccess: ({ serverId }) => {
      toast.success("Você entrou no servidor!");
      navigate(`/channels/${serverId}/first`);
    },
    onError: (e) => toast.error(e.message),
  });

  if (authLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-[var(--chat-bg)]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    navigate("/login", { replace: true });
    return null;
  }

  return (
    <div className="flex h-screen items-center justify-center bg-[var(--chat-bg)] p-4">
      <Card className="w-full max-w-sm text-center">
        <CardHeader>
          <div className="mx-auto mb-2 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/15 text-2xl font-bold text-primary">
            {info.data?.server.name?.slice(0, 2).toUpperCase() ?? "?"}
          </div>
          <CardTitle>
            {info.isLoading
              ? "Carregando convite..."
              : info.error
                ? "Convite inválido"
                : `Entrar em ${info.data?.server.name}`}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {info.isLoading ? (
            <Loader2 className="mx-auto h-6 w-6 animate-spin text-muted-foreground" />
          ) : info.error ? (
            <>
              <p className="text-sm text-muted-foreground">
                {info.error.message ?? "Este convite expirou ou não existe."}
              </p>
              <Button variant="secondary" className="w-full" onClick={() => navigate("/channels/@me")}>
                Voltar ao início
              </Button>
            </>
          ) : info.data ? (
            <>
              <p className="flex items-center justify-center gap-1.5 text-sm text-muted-foreground">
                <Users className="h-4 w-4" />
                {info.data.memberCount} {info.data.memberCount === 1 ? "membro" : "membros"}
              </p>
              {info.data.server.description && (
                <p className="text-sm text-muted-foreground">{info.data.server.description}</p>
              )}
              {info.data.alreadyMember ? (
                <Button
                  className="w-full"
                  onClick={() => navigate(`/channels/${info.data!.server.id}/first`)}
                >
                  Você já é membro — abrir servidor
                </Button>
              ) : (
                <Button className="w-full" onClick={() => join.mutate({ code })} disabled={join.isPending}>
                  {join.isPending ? "Entrando..." : "Aceitar convite"}
                </Button>
              )}
            </>
          ) : null}
        </CardContent>
      </Card>
    </div>
  );
}
